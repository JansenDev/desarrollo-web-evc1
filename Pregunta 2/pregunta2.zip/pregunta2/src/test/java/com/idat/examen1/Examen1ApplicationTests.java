package com.idat.examen1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examen1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
