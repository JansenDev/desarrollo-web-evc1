package com.idat.examen1.repository;

import com.idat.examen1.model.Prestamo;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface PrestamoRepository  {

    public abstract List<Prestamo> findAll();

    public abstract Prestamo save(Prestamo prestamo);

    public abstract Prestamo update(Prestamo prestamo);

    public abstract boolean deleteById(Long id);

    public abstract boolean existsById(Long id);

    public abstract Prestamo findById(Long id);
}
