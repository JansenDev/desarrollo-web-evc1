package com.idat.examen1.repository.impl;

import com.idat.examen1.model.Prestamo;
import com.idat.examen1.repository.PrestamoRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.*;

@Component
public class PrestamosRepositoryImpl implements PrestamoRepository {

    //    Map<Long, Prestamo> map = new HashMap();
    List<Prestamo> prestamos = new ArrayList();

    @Override
    public List<Prestamo> findAll() {
        return prestamos;
    }

    @Override
    public Prestamo save(Prestamo prestamo) {
        int index = prestamos.size() + 1;
        prestamo.setPrestamo_id((long) index);
        prestamo.setFecha(new Date());
        prestamos.add(prestamo);
        return prestamo;
    }

    @Override
    public Prestamo update(Prestamo prestamo) {

        int index = 0;
        for (Prestamo prestamoItem : prestamos) {
            if (Objects.equals(prestamoItem.getPrestamo_id(), prestamo.getPrestamo_id())) {
                prestamos.set(index, prestamo);
            }
            index++;
        }

        return prestamo;
    }

    @Override
    public boolean deleteById(Long id) {

        if (!existsById(id)) return false;

        int index = 0;
        for (Prestamo prestamo : prestamos) {
            if (Objects.equals(prestamo.getPrestamo_id(), id)) {
                prestamos.remove(index);
                return true;
            }
            index++;
        }
        return false;

    }

    @Override
    public boolean existsById(Long id) {

        try {
            for (Prestamo prestamo : prestamos) {
                if (Objects.equals(prestamo.getPrestamo_id(), id)) {
                    return true;
                }
            }
            return false;

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public Prestamo findById(Long id) {
        for (Prestamo prestamo : prestamos) {
            if (Objects.equals(prestamo.getPrestamo_id(), id)) {
                return prestamo;
            }
        }
        return new Prestamo();
    }
}
