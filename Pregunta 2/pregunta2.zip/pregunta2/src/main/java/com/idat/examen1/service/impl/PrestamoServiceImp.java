package com.idat.examen1.service.impl;

import com.idat.examen1.model.Prestamo;
import com.idat.examen1.repository.PrestamoRepository;
import com.idat.examen1.service.PrestamoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PrestamoServiceImp implements PrestamoService {

    @Autowired
    private PrestamoRepository prestamoRepository;

    @Override
    public boolean existsById(Long id){
        return prestamoRepository.existsById(id);
    }

    @Override
    public Prestamo findById(Long id) {
        return prestamoRepository.findById(id);
    }

    @Override
    public List<Prestamo> findAll() {
        return (List<Prestamo>) prestamoRepository.findAll();
    }

    @Override
    public Prestamo save(Prestamo prestamo) {
        return prestamoRepository.save(prestamo);
    }

    @Override
    public Prestamo update(Prestamo prestamo) {
        return prestamoRepository.update(prestamo);
    }

    @Override
    public boolean deleteById(Long id) {
        try {
            return prestamoRepository.deleteById(id);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }

    }
}
