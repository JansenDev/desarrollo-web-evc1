package com.idat.examen1.controller;

import com.idat.examen1.model.DataResponse;
import com.idat.examen1.model.Prestamo;
import com.idat.examen1.service.PrestamoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/prestamo")
public class PrestamoController {

    @Autowired
    private PrestamoService prestamoService;

    @GetMapping
    public ResponseEntity<DataResponse<List<Prestamo>>> findAll() {
        DataResponse<List<Prestamo>> dataResponse = new DataResponse();
        try {
            List<Prestamo> prestamos = prestamoService.findAll();
            dataResponse.setData(prestamos);
            dataResponse.setMessage("FindAll success");
            dataResponse.setHttpStatus(HttpStatus.OK);

            return new ResponseEntity(dataResponse, HttpStatus.OK);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            dataResponse.setMessage("FindAll error");
            dataResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

            return new ResponseEntity(dataResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PostMapping
    public ResponseEntity<DataResponse<Prestamo>> save(@RequestBody Prestamo prestamo) {
        DataResponse<Prestamo> dataResponse = new DataResponse();
        try {
            Prestamo prestamoSaved = prestamoService.save(prestamo);
            dataResponse.setData(prestamoSaved);
            dataResponse.setMessage("Save success");
            dataResponse.setHttpStatus(HttpStatus.CREATED);

            return new ResponseEntity(dataResponse, HttpStatus.CREATED);

        } catch (Exception e) {
            System.out.println(e.getMessage());
            dataResponse.setMessage("Save error");
            dataResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

            return new ResponseEntity(dataResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<DataResponse<Prestamo>> update(@PathVariable("id") Long id, @RequestBody Prestamo prestamo) {
        DataResponse<Prestamo> dataResponse = new DataResponse();
        System.out.println("START");
        System.out.println(prestamo.getPrestamo_id());
        System.out.println(prestamo.getFecha());
        try {
            boolean isExistsFound = prestamoService.existsById(id);
            boolean isEmptyFecha = prestamo.getFecha() == null;

            if (!isExistsFound) {
                dataResponse.setHttpStatus(HttpStatus.NOT_FOUND);
                dataResponse.setMessage("Not Exists prestamo with id: " + id);
                return new ResponseEntity(dataResponse, HttpStatus.NOT_FOUND);
            }

            Prestamo prestamoFound = prestamoService.findById(id);

            if (isEmptyFecha) prestamo.setFecha(prestamoFound.getFecha());

            prestamo.setPrestamo_id(id);
            Prestamo prestamoSaved = prestamoService.save(prestamo);
            dataResponse.setData(prestamoSaved);
            dataResponse.setMessage("Update success");
            dataResponse.setHttpStatus(HttpStatus.OK);

            return new ResponseEntity(dataResponse, HttpStatus.OK);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            dataResponse.setMessage("Update error");
            dataResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

            return new ResponseEntity(dataResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<DataResponse<?>> delete(@PathVariable("id") Long id) {
        DataResponse<Boolean> dataResponse = new DataResponse();
        Boolean isDeleted = prestamoService.deleteById(id);
        dataResponse.setData(isDeleted);
        dataResponse.setHttpStatus(HttpStatus.OK);

        if (isDeleted) {
            dataResponse.setMessage("delete success");
            return new ResponseEntity(dataResponse, HttpStatus.OK);
        }
        dataResponse.setMessage("delete error");

        return new ResponseEntity(dataResponse, HttpStatus.OK);
    }

}
