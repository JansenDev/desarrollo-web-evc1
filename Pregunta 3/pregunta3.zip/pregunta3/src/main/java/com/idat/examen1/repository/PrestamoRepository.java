package com.idat.examen1.repository;

import com.idat.examen1.model.Prestamo;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PrestamoRepository extends CrudRepository<Prestamo,Long> {
}
