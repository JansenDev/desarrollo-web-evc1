package com.idat.examen1.service.impl;

import com.idat.examen1.model.Prestamo;

import com.idat.examen1.service.PrestamoService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Service
public class PrestamoServiceImp implements PrestamoService {

    List<Prestamo> prestamos = new ArrayList();


   
    public List<Prestamo> findAll() {
        return prestamos;
    }

   
    public Prestamo save(Prestamo prestamo) {
        int index = prestamos.size() + 1;
        prestamo.setPrestamo_id((long) index);
        prestamo.setFecha(new Date());
        prestamos.add(prestamo);
        return prestamo;
    }

   
    public Prestamo update(Prestamo prestamo) {

        int index = 0;
        for (Prestamo prestamoItem : prestamos) {
            if (Objects.equals(prestamoItem.getPrestamo_id(), prestamo.getPrestamo_id())) {
                prestamos.set(index, prestamo);
            }
            index++;
        }

        return prestamo;
    }

   
    public boolean deleteById(Long id) {

        if (!existsById(id)) return false;

        int index = 0;
        for (Prestamo prestamo : prestamos) {
            if (Objects.equals(prestamo.getPrestamo_id(), id)) {
                prestamos.remove(index);
                return true;
            }
            index++;
        }
        return false;

    }

   
    public boolean existsById(Long id) {

        try {
            for (Prestamo prestamo : prestamos) {
                if (Objects.equals(prestamo.getPrestamo_id(), id)) {
                    return true;
                }
            }
            return false;

        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

   
    public Prestamo findById(Long id) {
        for (Prestamo prestamo : prestamos) {
            if (Objects.equals(prestamo.getPrestamo_id(), id)) {
                return prestamo;
            }
        }
        return new Prestamo();
    }
}
