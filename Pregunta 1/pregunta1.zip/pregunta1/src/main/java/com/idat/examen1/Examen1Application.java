package com.idat.examen1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Examen1Application {

    public static void main(String[] args) {
        SpringApplication.run(Examen1Application.class, args);
    }

}
