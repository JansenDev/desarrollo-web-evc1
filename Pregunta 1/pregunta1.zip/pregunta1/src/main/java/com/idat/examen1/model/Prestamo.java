package com.idat.examen1.model;

import java.io.Serializable;
import java.util.Date;

public class Prestamo implements Serializable {

    private static final long serialVersionUID = -456549626131462937L;


    private Long prestamo_id;


    private Integer client_id;


    private Date fecha;


    private Float monto;


    private String forma_pago;


    public Prestamo() {
    }

    public Prestamo(Long prestamo_id, Integer client_id, Date fecha, Float monto, String forma_pago) {
        this.prestamo_id = prestamo_id;
        this.client_id = client_id;
        this.fecha = fecha;
        this.monto = monto;
        this.forma_pago = forma_pago;
    }

    public Long getPrestamo_id() {
        return prestamo_id;
    }

    public void setPrestamo_id(Long prestamo_id) {
        this.prestamo_id = prestamo_id;
    }

    public Integer getClient_id() {
        return client_id;
    }

    public void setClient_id(Integer client_id) {
        this.client_id = client_id;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Date getFecha() {
        return fecha;
    }

    public Float getMonto() {
        return monto;
    }

    public void setMonto(Float monto) {
        this.monto = monto;
    }

    public String getForma_pago() {
        return forma_pago;
    }

    public void setForma_pago(String forma_pago) {
        this.forma_pago = forma_pago;
    }
}
